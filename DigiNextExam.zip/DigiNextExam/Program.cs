﻿using System;
using System.Linq;

namespace DigiNextExam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("please enter number of Question : ");
            Console.WriteLine("For Question 1 select 1");
            Console.WriteLine("For Question 2 select 2");
            Console.WriteLine("For Question 3 select 3");
            var Question = Console.ReadLine();
            switch (Question)
            {
                case "1":
                    {
                        Console.Clear();
                        Console.WriteLine("please enter string : ");
                        var inputString = Console.ReadLine();
                        Console.WriteLine("please enter counter : ");
                        var count = Console.ReadLine();
                        var result = Question1(inputString, Convert.ToInt32(count));
                        Console.WriteLine("Question Result 1 is : ");
                        Console.WriteLine(result);
                    }
                    break;
                case "2":
                    {
                        Console.Clear();
                        Console.WriteLine("please enter string : ");
                        var inputString = Console.ReadLine();
                        var result = Question2(inputString);
                        Console.WriteLine("Question Result 2 is : ");
                        Console.WriteLine(result);
                    }

                    break;
                case "3":
                    {
                        Console.Clear();
                        var input = new int[7] { 7, 1, 3, 2, 4, 5, 6 };
                        var result = Question3(input);
                        Console.WriteLine("Question Result 3 is : ");
                        Console.WriteLine(result);
                    }
                    break;
            }

            Console.ReadKey();
        }
        static public int Question1(string str, int count)
        {
            var strLength = str.Length;
            var reaming = count - strLength;
            while (reaming > 0)
            {
                str = str + str;
                strLength = str.Length;
                reaming = count - strLength;
            }
            str = str.Substring(0, count);
            var counta = str.ToCharArray().Count(c => c == 'a');
            return (counta);
        }

        static public int Question2(string str)
        {
            var mustTodelete = 0;
            for (var i = 1; i < str.Length; i++)
            {
                if (str[i] == str[i - 1])
                {
                    mustTodelete++;
                }
            }
            return mustTodelete;
        }

        static public int Question3(int[] input)
        {
            int result = 0;
            int temp;
            int counter = 0;
            for (int i = 0; i < input.Length; ++i)
            {
                if (input[i] - 1 == i)
                {

                    if (counter == input.Length) break;
                    counter++;
                    continue;
                }
                temp = input[input[i] - 1];
                input[input[i] - 1] = input[i];
                input[i] = temp;
                result++;
                i = counter;
            }
            return result;
        }
    }
}
